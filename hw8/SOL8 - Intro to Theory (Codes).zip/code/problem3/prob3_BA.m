% Problem 3: Ring networks: Bump attractors or an SNN
clear all
close all
clc
%% Bump attractor
N = 180;
W_0 = .45;
W_1 = 1.2;
theta = (0:(N-1))*2*pi/180;
v_th = 50;

% compute the weight matrix
W = computeW(W_0, W_1, theta);

dt = 0.002;
t_end = 200;
t = 0:dt:10;
tau = .1;
T = length(t);

%% a.) explore the emergence of the bump given non-specific input current
nruns = 4;
i0s = [0.5, v_th+1, v_th+10];
num_i0s = length(i0s);
i1 = 0;
rs = zeros(num_i0s,nruns,N,T);
bump_width = zeros(num_i0s, nruns);
bump_height = zeros(num_i0s, nruns);
for j=1:num_i0s
    i0 = i0s(j);
    ivec = i0*ones(N,1);
    for k=1:nruns
        fprintf('i0=%.1f, run %d\n', i0, k);
        r = zeros(N,T);
        r(:,1) = .01*normrnd(0, 1, [N,1]); % new ring initialization
        for i = 2:T
            input = W*r(:,i-1) + ivec - v_th;
            input(input < 0) = 0;
            dr = (dt/tau)*(-r(:,i-1) + input);
            r(:,i) = r(:,i-1) + dr;
        end
        bump_width(j,k) = nnz(r(:,end) > 1e-3)*(2*pi)/180;
        bump_height(j,k) = max(r(:,end));
        rs(j,k,:,:) = r;
    end
end

%% plot the ring model steady state for some random inits
legendstrs = cell(nruns,1);
for i = 1:nruns
    legendstrs{i} = sprintf('init %d', i);
end
fontsize = 16;
colorstrs = {'k', 'r', 'b', 'g'};
figure;
zmax = max(max(max(max(rs))));
buf = .2;
for j=1:num_i0s
    i0 = i0s(j);
    ivec = i0*ones(N,1);
    subplot(1,num_i0s,j);
    for k=1:nruns
        r_jk = rs(j,k,:,end);
        plotRingSolution(theta, r_jk, colorstrs{k});
    end
    wstr = sprintf('bump width %.2f (rads)', mean(bump_width(j,:))); 
    hstr = sprintf('bump height %.2f (r)', mean(bump_height(j,:))); 
    title({sprintf('I_0 = %.2f', i0), wstr, hstr}, 'FontSize', fontsize);
    xlabel('x', 'FontSize', fontsize);
    ylabel('y', 'FontSize', fontsize);
    zlabel('r', 'FontSize', fontsize);
    xlim([-1-buf, 1+buf]);
    ylim([-1-buf, 1+buf]);
    zlim([0,zmax]);
    view(45, 20);
    if (j==1)
        legend(legendstrs);
    end
end

%% b.) Compute the bump width angle
figure;
W_1s = [1.05, 1.25, 1.45];
num_W1s = length(W_1s);
angle_lim = pi/2
psi = 0:.01:(angle_lim);
G1 = (1/2*pi)*(psi - (sin(2*psi)/2));
subplot(1,num_W1s+1,1);
plot([0,angle_lim], [1,1], 'k');
hold on;
legendstrs = cell(1+num_W1s,1);
legendstrs{1} = '1';
cross_psis = zeros(num_W1s,1);
for i=1:num_W1s
    W_1 = W_1s(i);
    y = 2*W_1*G1;
    plot(psi, y);
    cross_psis(i) = psi(find(y>1, 1));
    legendstrs{i+1} = sprintf('W1=%.2f, psi=%.2f rads', W_1, cross_psis(i));
end
xlabel('\psi (rads)', 'FontSize', fontsize);
ylabel('2W_1 G_1(\psi)', 'FontSize', fontsize);
legend(legendstrs, 'FontSize', fontsize);
scatter(cross_psis, ones(num_W1s,1), 'k*');

i0 = 0.7;
bump_width = zeros(num_W1s, nruns);
for j=1:num_W1s
    W_1 = W_1s(j);
    W = computeW(W_0, W_1, theta);
    ivec = i0*ones(N,1);
    for k=1:nruns
        fprintf('i0=%.1f, run %d\n', i0, k);
        r = zeros(N,T);
        r(:,1) = .01*normrnd(0, 1, [N,1]); % new ring initialization
        for i = 2:T
            input = W*r(:,i-1) + ivec - v_th;
            input(input < 0) = 0;
            dr = (dt/tau)*(-r(:,i-1) + input);
            r(:,i) = r(:,i-1) + dr;
        end
        bump_width(j,k) = nnz(r(:,end) > 1e-3)*(2*pi)/180;
        rs(j,k,:,:) = r;
    end
end

% plot the ring model steady state for some random inits
legendstrs = cell(nruns,1);
for i = 1:nruns
    legendstrs{i} = sprintf('init %d', i);
end
fontsize = 16;
colorstrs = {'k', 'r', 'b', 'g'};
zmax = max(max(max(max(rs))));
buf = .2;
for j=1:num_W1s
    W_1 = W_1s(j);
    ivec = i0*ones(N,1);
    subplot(1,num_W1s+1,j+1);
    for k=1:nruns
        r_jk = rs(j,k,:,end);
        plotRingSolution(theta, r_jk, colorstrs{k});
    end
    wstr = sprintf('bump angle %.2f (rads)', mean(bump_width(j,:))/2); 
    title({sprintf('W_1 = %.2f', W_1), wstr}, 'FontSize', fontsize);
    xlabel('x', 'FontSize', fontsize);
    ylabel('y', 'FontSize', fontsize);
    zlabel('r', 'FontSize', fontsize);
    xlim([-1-buf, 1+buf]);
    ylim([-1-buf, 1+buf]);
    zlim([0,zmax]);
    view(45, 20);
    if (j==1)
        legend(legendstrs);
    end
end

% it's a little off, but at least the trend is there.


%% c.) See what happens to the bump when you stimulate at a particular ori
i0 = 0.7;
i1 = 0.1*(i0-v_th);
ivec = i0 + i1*cos(theta'-(pi/2));
rs = zeros(nruns, N, T);
for k=1:nruns
    fprintf('i0=%.1f, run %d\n', i0, k);
    r = zeros(N,T);
    r(:,1) = .01*normrnd(0, 1, [N,1]); % new ring initialization
    for i = 2:T
        input = W*r(:,i-1) + ivec - v_th;
        input(input < 0) = 0;
        dr = (dt/tau)*(-r(:,i-1) + input);
        r(:,i) = r(:,i-1) + dr;
    end
    rs(k,:,:) = r;
end

% plot the ring model steady state for some random inits
legendstrs = cell(nruns,1);
for i = 1:nruns
    legendstrs{i} = sprintf('init %d', i);
end
fontsize = 16;
colorstrs = {'k', 'r', 'b', 'g'};
zmax = max(max(max(rs)));
buf = .2;
figure;
for k=1:nruns
    r_jk = rs(k,:,end);
    plotRingSolution(theta, r_jk, colorstrs{k});
end
title('input biased to pi/2', 'FontSize', fontsize);
xlabel('x', 'FontSize', fontsize);
ylabel('y', 'FontSize', fontsize);
zlabel('r', 'FontSize', fontsize);
xlim([-1-buf, 1+buf]);
ylim([-1-buf, 1+buf]);
zlim([0,zmax]);
view(45, 20);
legend(legendstrs);

%% d.) Show that uniform solution is stable for low enough W1.

i0 = 0.7;
W_1 = 0.5;
W = computeW(W_0, W_1, theta);
ivec = i0*ones(N,1);
rs = zeros(nruns, N, T);
for k=1:nruns
    fprintf('i0=%.1f, run %d\n', i0, k);
    r = zeros(N,T);
    r(:,1) = .01*normrnd(0, 1, [N,1]); % new ring initialization
    for i = 2:T
        input = W*r(:,i-1) + ivec - v_th;
        input(input < 0) = 0;
        dr = (dt/tau)*(-r(:,i-1) + input);
        r(:,i) = r(:,i-1) + dr;
    end
    rs(k,:,:) = r;
end

% plot the ring model steady state for some random inits
legendstrs = cell(nruns,1);
for i = 1:nruns
    legendstrs{i} = sprintf('init %d', i);
end
fontsize = 16;
colorstrs = {'k', 'r', 'b', 'g'};
zmax = max(max(max(rs)));
buf = .2;
figure;
for k=1:nruns
    r_jk = rs(k,:,end);
    plotRingSolution(theta, r_jk, colorstrs{k});
end
title('Uniform input, low W_1', 'FontSize', fontsize);
xlabel('x', 'FontSize', fontsize);
ylabel('y', 'FontSize', fontsize);
zlabel('r', 'FontSize', fontsize);
xlim([-1-buf, 1+buf]);
ylim([-1-buf, 1+buf]);
zlim([0,zmax]);
view(45, 20);
legend(legendstrs);


%% now have a biased input
i0 = 0.7;
i1 = 0.1*(i0-v_th);
ivec = i0 + i1*cos(theta'-(pi/2));
rs = zeros(nruns, N, T);
for k=1:nruns
    fprintf('i0=%.1f, run %d\n', i0, k);
    r = zeros(N,T);
    r(:,1) = .01*normrnd(0, 1, [N,1]); % new ring initialization
    for i = 2:T
        input = W*r(:,i-1) + ivec - v_th;
        input(input < 0) = 0;
        dr = (dt/tau)*(-r(:,i-1) + input);
        r(:,i) = r(:,i-1) + dr;
    end
    rs(k,:,:) = r;
end

% plot the ring model steady state for some random inits
legendstrs = cell(nruns,1);
for i = 1:nruns
    legendstrs{i} = sprintf('init %d', i);
end
fontsize = 16;
colorstrs = {'k', 'r', 'b', 'g'};
zmax = max(max(max(rs)));
buf = .2;
figure;
for k=1:nruns
    r_jk = rs(k,:,end);
    plotRingSolution(theta, r_jk, colorstrs{k});
end
title('Biased input, low W_1 (no flat part)', 'FontSize', fontsize);
xlabel('x', 'FontSize', fontsize);
ylabel('y', 'FontSize', fontsize);
zlabel('r', 'FontSize', fontsize);
xlim([-1-buf, 1+buf]);
ylim([-1-buf, 1+buf]);
zlim([0,zmax]);
view(45, 20);
legend(legendstrs);