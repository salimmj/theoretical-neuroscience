%% Problem 3.) Stabilized supralinear network (SSN)
clear all
close all
clc
N = 180;
theta = 1:N;
J_EE = 0.044;
J_IE = 0.042;
J_EI = 0.023;
J_II = 0.018;
sigma_W = 32;

W = zeros(2*N, 2*N);
W_EE = zeros(N,N);
W_IE = zeros(N,N);
W_EI = zeros(N,N);
W_II = zeros(N,N);
for i = 1:N
    for j = 1:N
        W_EE(i,j) = J_EE*exp(-Theta(theta(i), theta(j)).^2/(2*(sigma_W^2)));
        W_IE(i,j) = J_IE*exp(-Theta(theta(i), theta(j)).^2/(2*(sigma_W^2)));
        W_EI(i,j) = J_EI*exp(-Theta(theta(i), theta(j)).^2/(2*(sigma_W^2)));
        W_II(i,j) = J_II*exp(-Theta(theta(i), theta(j)).^2/(2*(sigma_W^2)));
    end
end
W = [W_EE, -W_EI; W_IE, -W_II];
tau_E = .02;
tau_I = .01;
T = [tau_E, 0; 0, tau_I];
sigma_i = 30;
n = 2;
k = 0.04;
red =  0.8*[1, 0, 0];
blue = 0.8*[0, 0, 1];
%% a.) this is first
dt = .001;
npts = 500;
x = linspace(0, dt*(npts-1), npts);
theta0_ind = 45;
theta0 = theta(theta0_ind);

cs = [1.25, 2.5, 5, 10, 20, 40];
num_cs = length(cs);

rE = zeros(num_cs,1);
rI = zeros(num_cs,1);
FFi_E =zeros(num_cs,1);
FFi_I = zeros(num_cs,1);
reci_E = zeros(num_cs,1);
reci_I = zeros(num_cs,1);
totali_E = zeros(num_cs,1);
totali_I = zeros(num_cs,1);
perc_reci_E = zeros(num_cs, 1);
perc_reci_I = zeros(num_cs, 1);
perc_E_E = zeros(num_cs,1);
perc_E_I = zeros(num_cs,1);
rs_45 = zeros(num_cs, 2*N, npts);
for k=1:num_cs
    c = cs(k);
    ivec = zeros(2*N, 1);
    for i = 1:N
        ivec(i) = c*exp(-(Theta(theta(i), theta0).^2)/(2*(sigma_i^2)));
        ivec(N+i) = ivec(i);
    end
    r = zeros(2*N, npts);
    for t=2:npts
        input = W*r(:,t-1) + ivec;
        input(input < 0) = 0;
        drE = (dt/tau_E)*(-r(1:N,t-1) + k*((input(1:N).^n)));
        drI = (dt/tau_I)*(-r((N+1):(2*N),t-1) + k*((input((N+1):(2*N)).^n)));
        r(1:N,t) = r(1:N,t-1) + drE;
        r((N+1):(2*N),t) = r((N+1):(2*N),t-1) + drI;
    end
    rE(k) = r(theta0_ind,end);
    rI(k) = r(theta0_ind+N,end);
    FFi_E(k) = ivec(theta0_ind);
    FFi_I(k) = ivec(theta0_ind+N);
    Wr = W*r(:,end-1);
    reci_E(k) = Wr(theta0_ind);
    reci_I(k) = Wr(theta0_ind+N);
    E_E = W(theta0_ind,1:N)*r(1:N,end-1);
    I_E = -W(theta0_ind,(N+1):(2*N))*r((N+1):(2*N),end-1);
    totali_E(k) = FFi_E(k) + E_E + I_E;
    E_I = W(theta0_ind+N,1:N)*r(1:N,end-1);
    I_I = -W(theta0_ind+N,(N+1):(2*N))*r((N+1):(2*N),end-1);
    totali_I(k) = FFi_I(k) + E_I + I_I;
    perc_reci_E(k) = (E_E+I_E) / totali_E(k);
    perc_reci_I(k) = (E_I+I_I) / totali_I(k);
    perc_E_E(k) = E_E / (E_E + I_E);
    perc_E_I(k) = E_I / (E_I + I_I);
    rs_45(k,:,:) = r;
end

figure;
sizes = 40*ones(num_cs, 1);
fontsize = 16;
subplot(2,3,1);
scatter(cs, rE, sizes, red, 'filled');
hold on;
scatter(cs, rI, sizes, blue, 'filled');
xlabel('c', 'FontSize', fontsize);
ylabel('rate', 'FontSize', fontsize);
legend({'r_E', 'r_I'}, 'FontSize', fontsize);

subplot(2,3,2);
scatter(cs, FFi_E, sizes+10, red, 'filled');
hold on;
scatter(cs, FFi_I, sizes, blue, 'filled');
xlabel('c', 'FontSize', fontsize);
ylabel('input', 'FontSize', fontsize);
legend({'FF_E', 'FF_I'}, 'FontSize', fontsize);

subplot(2,3,3);
scatter(cs, reci_E, sizes, red, 'filled');
hold on;
scatter(cs, reci_I, sizes, blue, 'filled');
xlabel('c', 'FontSize', fontsize);
ylabel('input', 'FontSize', fontsize);
legend({'rec_E', 'rec_I'}, 'FontSize', fontsize);

subplot(2,3,4);
scatter(cs, totali_E, sizes, red, 'filled');
hold on;
scatter(cs, totali_I, sizes, blue, 'filled');
xlabel('c', 'FontSize', fontsize);
ylabel('input', 'FontSize', fontsize);
legend({'total_E', 'total_I'}, 'FontSize', fontsize);

subplot(2,3,5);
scatter(cs, perc_reci_E, sizes, red, 'filled');
hold on;
scatter(cs, perc_reci_I, sizes, blue, 'filled');
xlabel('c', 'FontSize', fontsize);
ylabel('percent', 'FontSize', fontsize);
legend({'rec/total E', 'rec/total I'}, 'FontSize', fontsize);

subplot(2,3,6);
scatter(cs, perc_E_E, sizes, red, 'filled');
hold on;
scatter(cs, perc_E_I, sizes, blue, 'filled');
xlabel('c', 'FontSize', fontsize);
ylabel('percent', 'FontSize', fontsize);
legend({'E/rec E', 'E/rec I'}, 'FontSize', fontsize);


%% b.) present two stimuli
theta_shift = 90;
theta1_ind = theta0_ind + theta_shift;
theta1 = theta(theta1_ind);
rs_both = zeros(num_cs, 2*N, npts);
for k=1:num_cs
    c = cs(k);
    ivec1 = zeros(2*N,1);
    ivec2 = zeros(2*N,1);
    for i = 1:N
        ivec1(i) = c*exp(-(Theta(theta(i), theta0).^2)/(2*(sigma_i^2)));
        ivec1(N+i) = ivec1(i);
        ivec2(i) = c*exp(-(Theta(theta(i), theta1).^2)/(2*(sigma_i^2)));
        ivec2(N+i) = ivec2(i);
    end
    ivec = ivec1 + ivec2;
    r = zeros(2*N, npts);
    for t=2:npts
        input = W*r(:,t-1) + ivec;
        input(input < 0) = 0;
        drE = (dt/tau_E)*(-r(1:N,t-1) + k*((input(1:N).^n)));
        drI = (dt/tau_I)*(-r((N+1):(2*N),t-1) + k*((input((N+1):(2*N)).^n)));
        r(1:N,t) = r(1:N,t-1) + drE;
        r((N+1):(2*N),t) = r((N+1):(2*N),t-1) + drI;
    end
    rs_both(k, :, :) = r;
end

rE_sum_one = zeros(num_cs, N);
rI_sum_one = zeros(num_cs, N);
rE_both = zeros(num_cs, N);
rI_both = zeros(num_cs, N);

for k = 1:num_cs
    for i = 1:N
        ind1 = i;
        ind2 = ind1 + theta_shift;
        if (ind2 > N)
            ind2 = ind2 - N;
        end
        rE_sum_one(k,i) = rs_45(k,ind1,end) + rs_45(k,ind2,end);
        rI_sum_one(k,i) = rs_45(k,ind1+N,end) + rs_45(k,ind2+N,end);
        rE_both(k,i) = rs_both(k,ind1,end);
        rI_both(k,i) = rs_both(k,ind1+N,end);
    end
end

ratio_E = rE_both(:,theta0_ind) ./ rE_sum_one(:,theta0_ind);
ratio_I = rI_both(:,theta0_ind) ./ rI_sum_one(:,theta0_ind);    

figure;
scatter(cs, ratio_E, sizes, red, 'filled');
hold on;
scatter(cs, ratio_I, sizes, blue, 'filled');
xlim([0,  45]);
ylim([0, 2.5]);
xlabel('c', 'FontSize', fontsize);
ylabel('ratio', 'FontSize', fontsize);
legend({'sum of single', 'both response'}, 'FontSize', fontsize);

%% c.)
ratio_E = rE_both ./ rE_sum_one;
ratio_I = rI_both ./ rI_sum_one;
for k = 1:num_cs
    figure;
    plot(theta, ratio_I(k,:));
    title(sprintf('c = %.2f', cs(k)), 'FontSize', fontsize);
    xlabel('theta (degrees)', 'FontSize', fontsize);
    ylabel('ratio', 'FontSize', fontsize);
end

    








