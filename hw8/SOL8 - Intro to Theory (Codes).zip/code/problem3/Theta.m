function angle = Theta(thetax, thetay)
    abs_diff = abs(thetax - thetay);
    angle = min(abs_diff, 180-abs_diff);
end