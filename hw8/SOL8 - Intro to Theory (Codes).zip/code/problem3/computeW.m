function [W] = computeW(W_0, W_1, theta)
%COMPUTEW Summary of this function goes here
%   Detailed explanation goes here
    N = length(theta);
    W = zeros(N,N);
    for i = 1:N
        for j = 1:N
            W_theta = W_0 + 2*W_1*cos(theta(i)-theta(j));
            W(i,j) = W_theta/180;
        end
    end
end

