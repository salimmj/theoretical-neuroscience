function [h] = plotRingSolution(theta, r,color)
%PLOTRINGSOLUTION Summary of this function goes here
%   Detailed explanation goes here
    N = length(theta);
    x = cos(theta);
    y = sin(theta);
    sizes = 40*ones(N,1);
    scatter3(x,y,r,sizes,color,'filled');
    hold on;
    %plot3(x,y,squeeze(r),color);
end

