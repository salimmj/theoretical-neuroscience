clear all
close all
clc

%% Plot for the ISN network
re = 0:.01:1;

Inull1 = sigmf(re, [20,0.65]);
Inull2 = sigmf(re, [20,0.5]);
Enull = 1-(4*re.^ 1 + -8*re.^2 + 5*re.^3);

fontsize = 20;
dotsize = 100;
purple = 0.6*[1, 0, 1];
green = 0.6*[0,1,0];
figure;
plot(re, Enull, 'r', 'LineWidth', 3);
hold on;
plot(re, Inull1, 'b', 'LineWidth', 3);
plot(re, Inull2, 'c', 'LineWidth', 3);
maxheadsize = 2;
arrowlen = 0.58;
% arrows for paradoxical effect
quiver(.63, .41, 0, arrowlen, 'Color', green, 'lineWidth', 2, 'MaxHeadSize', 0.2);
scatter(0.63, 0.405, dotsize, purple, 'filled');
scatter(0.47, 0.37, dotsize, 'm', 'filled');
req = 0.63:-0.01:.48;
Inull2q = sigmf(req, [20,0.5]);
plot(req, Inull2q, 'Color', green, 'LineWidth',1.7);
dx = -0.055;
dy = -.26;
quiver(.52, .6, dx, dy, 'Color', green, 'lineWidth', 2, 'MaxHeadSize', 0.6);

arrowlen = 0.08;
quiver(.00, .7, arrowlen , 0, 'k', 'lineWidth', 2, 'MaxHeadSize', maxheadsize/arrowlen);
quiver(0.18, 0.7, -arrowlen , 0, 'k', 'lineWidth', 2, 'MaxHeadSize', maxheadsize/arrowlen);
quiver(.1, .5, arrowlen , 0, 'k', 'lineWidth', 2, 'MaxHeadSize', maxheadsize/arrowlen);
quiver(0.27, 0.5, -arrowlen , 0, 'k', 'lineWidth', 2, 'MaxHeadSize', maxheadsize/arrowlen);
quiver(.77, .3, arrowlen , 0, 'k', 'lineWidth', 2, 'MaxHeadSize', maxheadsize/arrowlen);
quiver(0.95, 0.3, -arrowlen , 0, 'k', 'lineWidth', 2, 'MaxHeadSize', maxheadsize/arrowlen);xlim([0,1]);
quiver(.82, .2, arrowlen , 0, 'k', 'lineWidth', 2, 'MaxHeadSize', maxheadsize/arrowlen);
quiver(1, 0.2, -arrowlen , 0, 'k', 'lineWidth', 2, 'MaxHeadSize', maxheadsize/arrowlen);xlim([0,1]);
quiver(.5, .38, -arrowlen , 0, 'k', 'lineWidth', 2, 'MaxHeadSize', maxheadsize/arrowlen);
quiver(.52, 0.38, arrowlen , 0, 'k', 'lineWidth', 2, 'MaxHeadSize', maxheadsize/arrowlen);xlim([0,1]);
scatter(0.47, 0.37, dotsize, 'm', 'filled'); % on top of everything
ylim([0,1]);
legend({'E nullcline', 'I nullcline', 'new I nullcline', 'paradoxical effect', 'r_{SS}', 'r_{SSnew}'}, 'FontSize', fontsize);
xlabel('$r_E$', 'FontSize', fontsize, 'Interpreter', 'latex');
ylabel('$r_I$', 'FontSize', fontsize, 'Interpreter', 'latex');
set(gca,'xtick',[])
set(gca,'ytick',[])
title('ISN', 'FontSize', fontsize+2);

%% Plot for the non-ISN network
re = 0:.01:1;

Inull1 = sigmf(re, [20,0.65]);
Inull2 = sigmf(re, [20,0.5]);
Enull = 1-Inull2;

fontsize = 20;
purple = 0.6*[1, 0, 1];
figure;
plot(re, Enull, 'r', 'LineWidth', 3);
hold on;
plot(re, Inull1, 'b', 'LineWidth', 3);
plot(re, Inull2, 'c', 'LineWidth', 3);
scatter(0.575, 0.18, dotsize, purple, 'filled');
scatter(0.5, 0.5, dotsize, 'm', 'filled');

ylim([0,1]);
legend({'E nullcline', 'I nullcline', 'new I nullcline', 'r_{SS}', 'r_{SSnew}'}, 'FontSize', fontsize-2);
xlabel('$r_E$', 'FontSize', fontsize, 'Interpreter', 'latex');
ylabel('$r_I$', 'FontSize', fontsize, 'Interpreter', 'latex');
set(gca,'xtick',[])
set(gca,'ytick',[])
title('non-ISN', 'FontSize', fontsize+2);

