function [V,D] = get_sorted_eigs(W, property)
    [v, D] = eig(W);
    ds = diag(D);
    if (strcmp(property, 'real'))
        [reald_sorted, d_inds] = sort(real(ds), 'descend');
    elseif (strcmp(property, 'imag'))
        [absd_sorted, d_inds] = sort(imag(ds), 'descend');
    end
    V = v(:,d_inds);
    D = ds(d_inds);
    D(1:5)
end