function angle = Theta(x, y, theta)
    [x1,x2,y1,y2] = parse_vecs(x,y);
    abs_diff = abs(theta(x1,x2) - theta(y1,y2));
    angle = min(abs_diff, 180-abs_diff);
end