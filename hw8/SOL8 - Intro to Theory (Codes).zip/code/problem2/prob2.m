% Problem 2: Eigenvectors, Schur Vectors and Non-Normal Dynamics in Higher Dimensions
clear all
close all
clc

fontsize = 16;
%% Visualize the the orientation map

n = 32;
N = n^2;
theta = zeros(n, n);
% set the first 8x8 grid of tuning based on angle from center
for x = 1:8
    for y = 1:8
        theta_xy = (atan((x-4.5)/(y-4.5))*180)/pi;
        if (theta_xy < 0)
            theta_xy = theta_xy + 180;
        end
        theta(x,y) = theta_xy;
    end
end
% the 8x8 grid to the right is a reflection
for x = 9:16
    for y = 1:8
        theta(x,y) = theta(17-x, y);
    end
end
% the 8x8 grid above is a reflection
for x = 1:8
    for y = 9:16
        theta(x,y) = theta(x, 17-y);
    end
end
% the 8x8 grid above and to right is a reflection
for x = 9:16
    for y = 9:16
        theta(x,y) = theta(17-x, 17-y);
    end
end
% we can copy this 16x16 block to the remaining quadrants
theta(17:32,1:16) = theta(1:16, 1:16);
theta(1:16,17:32) = theta(1:16, 1:16);
theta(17:32,17:32) = theta(1:16, 1:16);

colormap(jet(256));
imagesc(theta);
% we need to flip the y-axis in imagesc so that y is increasing from
% bottom to top
set(gca,'YDir','normal')
xlabel('x', 'FontSize', fontsize);
ylabel('y', 'FontSize', fontsize);
h = colorbar;
colormap(hsv);
ylabel(h, 'orientation (degrees)', 'FontSize', fontsize, 'Rotation', 270, ...
          'Position', [3, 90]);
    
%% Compute the synaptic weights of the excitatory (E) and inhibitory (I) populations
preserve_symmetry = false;
sigma_theta = 20;
sigmaE_d = 23;
sigmaI_d = 2.3;

% Students should use equation 5.
W_E = zeros(N,N);
W_I = zeros(N,N);
d_mat = zeros(N,N);
theta_mat = zeros(N,N);
for x2 = 1:n
    for x1 = 1:n
        x = [x1, x2];
        x_ind = (x2-1)*n+x1;
        for y2 = 1:n
            for y1 = 1:n
                y = [y1, y2];
                y_ind = (y2-1)*n+y1;
                d_mat(x_ind, y_ind) = d(x,y);
                theta_mat(x_ind, y_ind) = Theta(x,y,theta);
                W_E(x_ind,y_ind) = exp(-(d(x,y)^2)/(2*(sigmaE_d^2))) * exp(-(Theta(x,y,theta)^2)/(2*(sigma_theta^2)));
                W_I(x_ind,y_ind) = exp(-(d(x,y)^2)/(2*(sigmaI_d^2))) * exp(-(Theta(x,y,theta)^2)/(2*(sigma_theta^2)));
            end
        end
    end
end

%% normalize the rows

% Normalize the incoming weights to each cell so that they sum to 20 from
% both populations
if (preserve_symmetry)
    % Use an iterative scheme to leave previous row-column pairs immutable
    for i = 1:N
      fac = (20-sum(W_E(i,1:(i-1))))/sum(W_E(i,i:end));
      W_Ei_new = fac*W_E(i,i:end);
      W_E(i,i:end) = W_Ei_new;
      W_E(i:end,i) = W_Ei_new; 

      fac = (20-sum(W_I(i,1:(i-1))))/sum(W_I(i,i:end));
      W_Ii_new = fac*W_I(i,i:end);
      W_I(i,i:end) = W_Ii_new;
      W_I(i:end,i) = W_Ii_new; 
    end
else
    % Just do this the simple way and don't worry about symmetry
    % preservation
    for i = 1:N
      Efac = 20/sum(W_E(i,:));
      W_E(i,:) = Efac*W_E(i,:);
      Ifac = 20/sum(W_I(i,:));
      W_I(i,:) = Ifac*W_I(i,:);
    end
end

%% a.) plot the 5 greatest eigenvectors of the E-I difference matrix
WD = W_E - W_I;
[V, lambdaD] = get_sorted_eigs(WD, 'real');
figure;
for i = 1:5
    subplot(2,3,i);
    Vi = real(V(:,i));
    Vi_spatial = vec2mat(Vi, n)';
    colormap(jet(256));
    imagesc(Vi_spatial);
    title(sprintf('$e_%d^D$, $\\lambda_%d=%.2e$', i, i, lambdaD(i)), 'FontSize', fontsize, 'Interpreter', 'latex');
    set(gca,'YDir','normal')
    xlabel('x', 'FontSize', fontsize);
    ylabel('y', 'FontSize', fontsize);
    h = colorbar;
end


%% b.) plot the steady state response to inputs at 0 and 90 degrees
typestrs = {'E', 'I'};
W = [W_E, -W_I; W_E, -W_I];
theta0s = [0, 90];
K = length(theta0s);

r = zeros(2*N, K);
for k=1:K
    theta0 = theta0s(k);
    ivec = zeros(2*N,1);
    for x2 = 1:n
        for x1 = 1:n
            x = [x1, x2];
            x_ind = (x2-1)*n+x1;
            ivec(x_ind) = 4*exp(-((theta0-theta(x1, x2))^2)/(2*(20^2)));
        end
    end
    ivec((N+1):end,1) = ivec(1:N,1);
    r_k = (eye(2*N)-W)\ivec;
    r_spatial = vec2mat(r_k, n)';

    figure;
    for i = 1:2
        subplot(1,2,i);
        typestr = typestrs{i};
        colormap(jet(256));
        imagesc(r_spatial(:,((i-1)*n+1):i*n));
        set(gca,'YDir','normal')
        xlabel('x', 'FontSize', fontsize);
        ylabel('y', 'FontSize', fontsize);
        title(sprintf('%s population', typestr), 'FontSize', fontsize);
        h = colorbar;
    end
    suptitle(sprintf('theta_0 = %d', theta0));
    
    r(:,k) = r_k;
end

%% c.) Compute the correlation of the responses with the eigenvectors
eD = zeros(N,5);
for k = 1:K
    r_k = r(1:N,k);
    for i = 1:5
        eD(:,i) = V(:,i);
        corrs = corrcoef(r_k, real(eD(:,i)));
        fprintf('Ori %d, Eig %d: corr = %f\n', theta0s(k), i, corrs(1,2));        
    end
end

%% d.) plot the 5 greatest eigenvectors of the E+I sum matrix
WS = W_E + W_I;
[V, lambdaS] = get_sorted_eigs(WS, 'real');
figure;
for i = 1:5
    subplot(2,3,i);
    Vi = real(V(:,i));
    Vi_spatial = vec2mat(Vi, n)';
    colormap(jet(256));
    imagesc(Vi_spatial);
    title(sprintf('$e_%d^S$, $\\lambda_%d=%.1f$', i, i, lambdaS(i)), 'FontSize', fontsize, 'Interpreter', 'latex');
    set(gca,'YDir','normal')
    xlabel('x', 'FontSize', fontsize);
    ylabel('y', 'FontSize', fontsize);
    h = colorbar;
end

%% e.) Written


%% f.) Compute the correlation of the responses with the eigenvectors
eS = zeros(N,5);
for k = 1:K
    r_k = r(1:N,k);
    for i = 1:5
        eS(:,i) = V(:,i);
        corrs = corrcoef(r_k, real(eS(:,i)));
        fprintf('Ori %d, Eig %d: corr = %f\n', theta0s(k), i, corrs(1,2));        
    end
end

%% g.) Plot the non-normal amplification of the model
dt = .05;
tau  = 1;
t_end = 10;
t = 0:dt:t_end;
T = length(t);
figure;
red =  0.8*[1, 0, 0];
blue = 0.8*[0, 0, 1];
lw = 2;
for i = 1:5
    subplot(2,3,i);
    % Simulate the network given initialization of [eSi; -eSi]
    r = zeros(2*N,T);
    r(1:N,1) = (1/sqrt(2))*eS(:,i);
    r((N+1):(2*N),1) = -(1/sqrt(2))*eS(:,i);
    for j=2:T
        dr = (dt/tau)*(-r(:,j-1) + W*r(:,j-1));
        r(:,j) = r(:,j-1) + dr;
    end
    % compute the normalized rate for each population
    rnorm = zeros(1,T);
    for j = 1:T
        rnorm(j) = norm(r(:,j));
    end
    plot(t, rnorm, 'Color', blue, 'LineWidth', lw);
    hold on;
    if (i < 4)
        transient1 = abs(lambdaS(i))*exp(-t/tau);
    else
        transient1 = max(rnorm)*exp(-t/tau);
    end
    transient2 = abs(lambdaS(i))*t.*exp(-t/tau);
    plot(t, transient2, 'r--', 'LineWidth', lw/2);
    plot(t, transient1, 'r-', 'LineWidth', lw/2);
    legend({'|r|','transient ceiling','transient floor'});
    xlabel('t (s)', 'FontSize', fontsize);
    ylabel('|r|', 'FontSize', fontsize);
    title(sprintf('$r_0$ = [$e_%d^S$; -$e_%d^S$]', i, i), ...
          'FontSize', fontsize, 'Interpreter', 'latex');
end