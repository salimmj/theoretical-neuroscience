function dist = d(x,y)
    [x1,x2,y1,y2] = parse_vecs(x,y);
    min1 = min((x1-y1)^2, (32-abs(x1-y1))^2);
    min2 = min((x2-y2)^2, (32-abs(x2-y2))^2);
    dist = sqrt(min1 + min2);
end