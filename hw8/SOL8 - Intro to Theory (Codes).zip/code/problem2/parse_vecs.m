function [x1,x2,y1,y2] = parse_vecs(x,y)
    assert(length(x)==2);
    assert(length(y)==2);
    x1 = x(1);
    x2 = x(2);
    y1 = y(1);
    y2 = y(2);
end
