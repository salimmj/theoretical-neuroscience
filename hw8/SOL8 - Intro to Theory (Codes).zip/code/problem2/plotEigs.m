function [h] = plotEigs(V, lambdas, label, lim)
%PLOTEIGS Summary of this function goes here
%   Detailed explanation goes here
%% plot distribution of real and imaginary components of eigvecs and vals
    N = length(lambdas);
    h = figure;
    subplot(2,1,1);
    plot(1:lim, real(lambdas(1:lim)));
    hold on;
    plot(1:lim, imag(lambdas(1:lim)));
    legend({'real', 'imag'});
    ylabel('eigenvalues');
    xlabel('eigenvalue indexes (sorted by real part)');
    title(label, 'FontSize', 20);
    
    subplot(2,1,2);
    realV = real(V);
    imagV = imag(V);
    realV_norms = zeros(N,1);
    imagV_norms = zeros(N,1);
    for i=1:N
        realV_norms(i) = norm(realV(:,i));
        imagV_norms(i) = norm(imagV(:,i));
    end
    plot(1:lim, realV_norms(1:lim));
    hold on;
    plot(1:lim, imagV_norms(1:lim));
    legend({'real V norm', 'imag V norm'});
    ylabel('eigenvector norms');
    xlabel('eigenvector indexes (sorted by real part of eigval)');
    
end

